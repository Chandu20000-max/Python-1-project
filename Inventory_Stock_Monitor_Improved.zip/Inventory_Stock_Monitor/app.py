import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from datetime import date
from inventory_manager import (
    load_inventory, save_inventory, add_product, update_product,
    delete_product, low_stock_items, summary, export_report,
    import_csv, CATEGORIES
)

st.set_page_config(page_title="Inventory Stock Monitor", page_icon="📦", layout="wide")
DATA_DIR = Path(__file__).parent / "data"
CSV_FILE = DATA_DIR / "inventory.csv"
JSON_FILE = DATA_DIR / "inventory.json"

if "inventory" not in st.session_state:
    st.session_state.inventory = load_inventory(JSON_FILE, CSV_FILE)

def persist():
    save_inventory(st.session_state.inventory, JSON_FILE, CSV_FILE)

def money(value):
    return f"₹{value:,.2f}"

st.markdown("""
<style>
.main {background-color:#f6f8fc;}
.block-container {padding-top:2rem;}
[data-testid="stMetric"] {background:white;padding:16px;border-radius:12px;border:1px solid #e8edf5;}
div.stButton > button {border-radius:8px;font-weight:600;}
</style>
""", unsafe_allow_html=True)

st.title("📦 Inventory Stock Monitor")
st.caption("A simple local inventory management system for small businesses and retail stores.")

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Choose a page", ["Dashboard", "Inventory", "Add Product", "Reports & Import"])
    st.divider()
    st.caption("Data is saved locally in CSV and JSON files.")
    st.caption(f"Products tracked: {len(st.session_state.inventory)}")

items = st.session_state.inventory

if page == "Dashboard":
    st.subheader("Overview")
    stats = summary(items)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total products", stats["total_products"])
    c2.metric("Total units", stats["total_units"])
    c3.metric("Inventory value", money(stats["total_value"]))
    c4.metric("Low-stock items", stats["low_stock_count"], delta_color="inverse")
    st.divider()
    left, right = st.columns([1.3, 1])
    with left:
        st.markdown("#### Stock by category")
        if items:
            df = pd.DataFrame(items)
            chart_data = df.groupby("category")["quantity"].sum().sort_values(ascending=False)
            fig, ax = plt.subplots(figsize=(7, 3.5))
            chart_data.plot(kind="bar", ax=ax)
            ax.set_ylabel("Units in stock")
            ax.set_xlabel("")
            ax.grid(axis="y", alpha=.2)
            st.pyplot(fig, use_container_width=True)
        else:
            st.info("Add products to see category analytics.")
    with right:
        st.markdown("#### Stock status")
        if items:
            low = stats["low_stock_count"]
            healthy = stats["total_products"] - low
            fig, ax = plt.subplots(figsize=(4, 3.5))
            ax.pie([healthy, low], labels=["Healthy", "Low stock"], autopct="%1.0f%%", startangle=90)
            ax.axis("equal")
            st.pyplot(fig, use_container_width=True)
        else:
            st.info("No inventory data yet.")
    st.markdown("#### ⚠️ Low-stock alerts")
    alerts = low_stock_items(items)
    if alerts:
        st.warning(f"{len(alerts)} product(s) are at or below their reorder level.")
        st.dataframe(pd.DataFrame(alerts)[["name", "category", "quantity", "reorder_level"]], use_container_width=True, hide_index=True)
    else:
        st.success("All products are above their reorder levels.")

elif page == "Inventory":
    st.subheader("Inventory records")
    q1, q2, q3 = st.columns([2, 1, 1])
    query = q1.text_input("Search by product name or SKU")
    categories = ["All"] + CATEGORIES
    category = q2.selectbox("Category", categories)
    status = q3.selectbox("Stock status", ["All", "Low stock", "Healthy"])
    filtered = items
    if query:
        filtered = [x for x in filtered if query.lower() in x["name"].lower() or query.lower() in x["sku"].lower()]
    if category != "All":
        filtered = [x for x in filtered if x["category"] == category]
    if status == "Low stock":
        filtered = [x for x in filtered if x["quantity"] <= x["reorder_level"]]
    elif status == "Healthy":
        filtered = [x for x in filtered if x["quantity"] > x["reorder_level"]]
    st.caption(f"Showing {len(filtered)} of {len(items)} products")
    if filtered:
        view = pd.DataFrame(filtered)
        view["stock_status"] = view.apply(lambda r: "LOW STOCK" if r.quantity <= r.reorder_level else "Healthy", axis=1)
        st.dataframe(view[["sku","name","category","quantity","reorder_level","unit_price","stock_status"]], use_container_width=True, hide_index=True)
    else:
        st.info("No matching products found.")
    st.divider()
    st.markdown("#### Update or delete a product")
    if items:
        labels = {f'{x["sku"]} — {x["name"]}': x["sku"] for x in items}
        selected_label = st.selectbox("Select product", list(labels))
        selected = next(x for x in items if x["sku"] == labels[selected_label])
        with st.form("edit_product"):
            a,b,c = st.columns(3)
            new_name = a.text_input("Product name", selected["name"])
            new_category = b.selectbox("Category", CATEGORIES, index=CATEGORIES.index(selected["category"]) if selected["category"] in CATEGORIES else 0)
            new_qty = c.number_input("Quantity", min_value=0, max_value=1000000, value=int(selected["quantity"]))
            d,e = st.columns(2)
            new_reorder = d.number_input("Reorder level", min_value=0, max_value=1000000, value=int(selected["reorder_level"]))
            new_price = e.number_input("Unit price (₹)", min_value=0.0, value=float(selected["unit_price"]), step=1.0)
            submitted = st.form_submit_button("Save changes", type="primary")
        if submitted:
            try:
                update_product(items, selected["sku"], name=new_name, category=new_category, quantity=new_qty, reorder_level=new_reorder, unit_price=new_price)
                persist()
                st.success("Product updated.")
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))
        if st.button("Delete selected product", type="secondary"):
            delete_product(items, selected["sku"])
            persist()
            st.success("Product deleted.")
            st.rerun()
    else:
        st.caption("There are no products to edit.")

elif page == "Add Product":
    st.subheader("Add a new product")
    with st.form("add_product", clear_on_submit=True):
        a,b = st.columns(2)
        sku = a.text_input("SKU / Product code *", placeholder="e.g. SKU-1001")
        name = b.text_input("Product name *", placeholder="e.g. Basmati Rice 5kg")
        c,d,e = st.columns(3)
        category = c.selectbox("Category", CATEGORIES)
        quantity = d.number_input("Current quantity", min_value=0, max_value=1000000, value=10)
        reorder = e.number_input("Reorder level", min_value=0, max_value=1000000, value=5)
        price = st.number_input("Unit price (₹)", min_value=0.0, value=10.0, step=1.0)
        submitted = st.form_submit_button("Add product", type="primary")
    if submitted:
        try:
            add_product(items, {"sku": sku, "name": name, "category": category, "quantity": quantity, "reorder_level": reorder, "unit_price": price})
            persist()
            st.success(f"{name} added successfully.")
            st.rerun()
        except ValueError as exc:
            st.error(str(exc))

elif page == "Reports & Import":
    st.subheader("Reports and data management")
    stats = summary(items)
    a,b,c = st.columns(3)
    a.metric("Products", stats["total_products"])
    b.metric("Units", stats["total_units"])
    c.metric("Total value", money(stats["total_value"]))
    st.markdown("#### Export reports")
    col1,col2,col3 = st.columns(3)
    csv_bytes = export_report(items, "csv")
    json_bytes = export_report(items, "json")
    md_bytes = export_report(items, "markdown").encode("utf-8")
    col1.download_button("⬇️ Download CSV", csv_bytes, "inventory_report.csv", "text/csv", use_container_width=True)
    col2.download_button("⬇️ Download JSON", json_bytes, "inventory_report.json", "application/json", use_container_width=True)
    col3.download_button("⬇️ Download Markdown", md_bytes, "inventory_report.md", "text/markdown", use_container_width=True)
    st.divider()
    st.markdown("#### Import products from CSV")
    uploaded = st.file_uploader("Upload a CSV with columns: sku, name, category, quantity, reorder_level, unit_price", type=["csv"])
    if uploaded and st.button("Import CSV", type="primary"):
        try:
            count, errors = import_csv(items, uploaded)
            persist()
            st.success(f"Imported {count} product(s).")
            if errors:
                st.warning("Some rows were skipped:")
                for error in errors:
                    st.write("• " + error)
            st.rerun()
        except Exception as exc:
            st.error(f"Could not import file: {exc}")
    st.caption("The application also saves inventory.json and inventory.csv in the data folder automatically.")
