import pytest
from inventory_manager import *
def product(): return {'sku':'T1','name':'Test Rice','category':'Grocery','quantity':10,'reorder_level':3,'unit_price':50}
def test_validate(): assert validate_product(product())['unit_price']==50.0
@pytest.mark.parametrize('field,value',[('sku',''),('name',''),('quantity',-1),('category','bad'),('unit_price',-1)])
def test_invalid(field,value):
 p=product(); p[field]=value
 with pytest.raises(ValidationError): validate_product(p)
def test_duplicate():
 x=[]; add_product(x,product())
 with pytest.raises(DuplicateSKUError): add_product(x,product())
def test_update_delete():
 x=[product()]; update_product(x,'T1',quantity=2); assert x[0]['quantity']==2; delete_product(x,'T1'); assert not x
def test_low_stock_summary():
 x=[product(),{**product(),'sku':'T2','quantity':2}]; assert len(low_stock_items(x))==1; assert summary(x)['total_units']==12
def test_missing_product():
 with pytest.raises(ProductNotFoundError): update_product([],'missing',quantity=2)
