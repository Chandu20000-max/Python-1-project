import csv, json, logging, sqlite3
from contextlib import contextmanager
from io import StringIO
from pathlib import Path
import portalocker
CATEGORIES=["Grocery","Dairy","Beverages","Snacks","Personal Care","Household","Electronics","Other"]
FIELDS=["sku","name","category","quantity","reorder_level","unit_price"]
logger=logging.getLogger("inventory")
class InventoryError(Exception): pass
class ValidationError(InventoryError,ValueError): pass
class DuplicateSKUError(InventoryError,ValueError): pass
class ProductNotFoundError(InventoryError,ValueError): pass

def validate_product(p):
    sku=str(p.get('sku','')).strip(); name=str(p.get('name','')).strip(); cat=str(p.get('category','Other')).strip()
    if not sku: raise ValidationError('SKU cannot be blank.')
    if not name: raise ValidationError('Product name cannot be blank.')
    if cat not in CATEGORIES: raise ValidationError('Choose a valid category.')
    try: qty=int(p.get('quantity',0)); reorder=int(p.get('reorder_level',0)); price=float(p.get('unit_price',0))
    except (TypeError,ValueError): raise ValidationError('Quantity, reorder level and price must be numeric.')
    if min(qty,reorder,price)<0: raise ValidationError('Quantity, reorder level and price cannot be negative.')
    if max(qty,reorder)>1000000: raise ValidationError('Quantity and reorder level must not exceed 1,000,000.')
    return dict(sku=sku,name=name,category=cat,quantity=qty,reorder_level=reorder,unit_price=round(price,2))

def _db(json_path): return Path(json_path).parent/'inventory.db'
@contextmanager
def _connect(path):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    with portalocker.Lock(str(path)+'.lock',mode='a',timeout=10):
        con=sqlite3.connect(path,timeout=10); con.row_factory=sqlite3.Row
        try:
            con.execute('CREATE TABLE IF NOT EXISTS products (sku TEXT PRIMARY KEY COLLATE NOCASE, name TEXT NOT NULL, category TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity>=0), reorder_level INTEGER NOT NULL CHECK(reorder_level>=0), unit_price REAL NOT NULL CHECK(unit_price>=0))'); con.commit(); yield con
        finally: con.close()
def _rows(con): return [dict(r) for r in con.execute('SELECT * FROM products ORDER BY name')]
def load_inventory(json_path,csv_path):
    root=Path(json_path).parent; root.mkdir(parents=True,exist_ok=True)
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        h=logging.FileHandler(root/'inventory.log',encoding='utf-8'); h.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s')); logger.addHandler(h)
    with _connect(_db(json_path)) as con:
        rows=_rows(con)
        if rows: return rows
        legacy=[]; jp=Path(json_path); cp=Path(csv_path)
        try:
            if jp.exists(): legacy=json.loads(jp.read_text(encoding='utf-8'))
            elif cp.exists():
                with cp.open(newline='',encoding='utf-8') as f: legacy=list(csv.DictReader(f))
        except (OSError,json.JSONDecodeError,csv.Error) as e: logger.warning('Legacy data read failed: %s',e)
        for row in legacy if isinstance(legacy,list) else []:
            try:
                x=validate_product(row); con.execute('INSERT OR IGNORE INTO products VALUES (?,?,?,?,?,?)',tuple(x[k] for k in FIELDS))
            except (ValidationError,TypeError) as e: logger.warning('Skipped invalid legacy row: %s',e)
        con.commit(); return _rows(con)
def save_inventory(items,json_path,csv_path):
    clean=[validate_product(x) for x in items]
    with _connect(_db(json_path)) as con:
        con.execute('BEGIN IMMEDIATE'); con.execute('DELETE FROM products'); con.executemany('INSERT INTO products VALUES (?,?,?,?,?,?)',[tuple(x[k] for k in FIELDS) for x in clean]); con.commit()
    Path(json_path).write_text(json.dumps(clean,indent=2),encoding='utf-8')
    with Path(csv_path).open('w',newline='',encoding='utf-8') as f: w=csv.DictWriter(f,fieldnames=FIELDS); w.writeheader(); w.writerows(clean)
    logger.info('Saved %d products',len(clean))
def add_product(items,p):
    x=validate_product(p)
    if any(i['sku'].lower()==x['sku'].lower() for i in items): raise DuplicateSKUError('A product with this SKU already exists.')
    items.append(x); logger.info('Added SKU %s',x['sku'])
def update_product(items,sku,**changes):
    i=next((n for n,x in enumerate(items) if x['sku'].lower()==sku.lower()),None)
    if i is None: raise ProductNotFoundError('Product not found.')
    x=validate_product({**items[i],**changes})
    if any(j!=i and p['sku'].lower()==x['sku'].lower() for j,p in enumerate(items)): raise DuplicateSKUError('A product with this SKU already exists.')
    items[i]=x; logger.info('Updated SKU %s',sku)
def delete_product(items,sku):
    n=len(items); items[:]=[x for x in items if x['sku'].lower()!=sku.lower()]
    if len(items)==n: raise ProductNotFoundError('Product not found.')
    logger.info('Deleted SKU %s',sku)
def low_stock_items(items): return [x for x in items if x['quantity']<=x['reorder_level']]
def summary(items): return {'total_products':len(items),'total_units':sum(x['quantity'] for x in items),'total_value':round(sum(x['quantity']*x['unit_price'] for x in items),2),'low_stock_count':len(low_stock_items(items)),'average_quantity':round(sum(x['quantity'] for x in items)/len(items),2) if items else 0}
def export_report(items,fmt):
    if fmt=='csv':
        out=StringIO(); w=csv.DictWriter(out,fieldnames=FIELDS); w.writeheader(); w.writerows(items); return out.getvalue().encode()
    if fmt=='json': return json.dumps(items,indent=2).encode()
    s=summary(items); lines=['# Inventory Stock Monitor Report',f"- Products: {s['total_products']}",f"- Total units: {s['total_units']}",f"- Total inventory value: Rs. {s['total_value']:.2f}",f"- Low-stock products: {s['low_stock_count']}",'','| SKU | Product | Category | Qty | Reorder | Unit price |','|---|---|---|---:|---:|---:|']
    lines += [f"| {x['sku']} | {x['name']} | {x['category']} | {x['quantity']} | {x['reorder_level']} | {x['unit_price']:.2f} |" for x in items]
    return '\n'.join(lines)
def import_csv(items,file_obj):
    import pandas as pd
    df=pd.read_csv(file_obj); missing=[x for x in FIELDS if x not in df.columns]
    if missing: raise ValidationError('Missing required columns: '+', '.join(missing))
    count=0; errors=[]
    for idx,row in df.iterrows():
        try: add_product(items,row.to_dict()); count+=1
        except (InventoryError,TypeError) as e: errors.append(f'Row {idx+2}: {e}')
    logger.info('CSV import: %d imported, %d skipped',count,len(errors)); return count,errors
