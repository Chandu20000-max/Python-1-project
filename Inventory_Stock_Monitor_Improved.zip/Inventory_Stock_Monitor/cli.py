from pathlib import Path
from inventory_manager import *

ROOT = Path(__file__).parent
JSON_FILE, CSV_FILE = ROOT / "data" / "inventory.json", ROOT / "data" / "inventory.csv"
inventory = load_inventory(JSON_FILE, CSV_FILE)

def ask_int(prompt):
    while True:
        try:
            value = int(input(prompt))
            if value < 0: raise ValueError
            return value
        except ValueError:
            print("Enter a whole number greater than or equal to 0.")

def main():
    while True:
        print("\\n========== INVENTORY STOCK MONITOR ==========")
        print("1. View inventory  2. Add product  3. Search")
        print("4. Low-stock items 5. Summary 6. Export report 0. Exit")
        choice = input("Choose: ").strip()
        if choice == "1":
            for p in inventory: print(p)
        elif choice == "2":
            try:
                product = {"sku": input("SKU: "), "name": input("Name: "),
                    "category": input(f"Category {CATEGORIES}: ").strip(),
                    "quantity": ask_int("Quantity: "), "reorder_level": ask_int("Reorder level: "),
                    "unit_price": input("Unit price: ")}
                add_product(inventory, product); save_inventory(inventory, JSON_FILE, CSV_FILE)
                print("Product added.")
            except ValueError as e: print("Error:", e)
        elif choice == "3":
            q = input("Search name or SKU: ").lower()
            for p in inventory:
                if q in p["name"].lower() or q in p["sku"].lower(): print(p)
        elif choice == "4":
            for p in low_stock_items(inventory): print("LOW STOCK:", p)
        elif choice == "5":
            print(summary(inventory))
        elif choice == "6":
            path = ROOT / "reports" / "inventory_report.md"
            path.write_text(export_report(inventory, "markdown"), encoding="utf-8")
            print("Saved:", path)
        elif choice == "0":
            save_inventory(inventory, JSON_FILE, CSV_FILE); print("Goodbye!"); break
        else: print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
