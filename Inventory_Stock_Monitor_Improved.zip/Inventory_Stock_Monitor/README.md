# Inventory Stock Monitor — Improved Edition

Updated using the Attempt #1 evaluation report. Retains the Streamlit web interface and CLI.

## Improvements
- SQLite (`data/inventory.db`) is now the primary database. Existing JSON/CSV data is migrated on first launch.
- Portalocker protects database access during simultaneous CLI/web operations.
- Activity and warnings are recorded in `data/inventory.log`.
- Custom exceptions: `ValidationError`, `DuplicateSKUError`, `ProductNotFoundError`.
- Pytest automated tests for validation, CRUD, low-stock checks and summary calculations.
- JSON and CSV backup copies and existing report exports are retained.

## Run on Windows / VS Code
```powershell
python -m venv venv
.\venv\Scripts\activate
python -m pip install -r requirements.txt
streamlit run app.py
```
Open the Local URL shown in the terminal (usually http://localhost:8501).

## Run tests
```powershell
python -m pytest -v
```

## Run terminal interface
```powershell
python cli.py
```

## Data files
- `data/inventory.db`: primary SQLite database
- `data/inventory.csv` and `data/inventory.json`: backup/export copies
- `data/inventory.log`: activity log

Keep `inventory.db` to preserve current data.
